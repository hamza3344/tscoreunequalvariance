﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace tscorewithunequalvariance
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            List<double> sampleone = new List<double>();
            List<double> sampletwo = new List<double>();
            foreach(string s in textBox1.Text.Split(","))
            {
                sampleone.Add(double.Parse(s));
            }foreach(string s in textBox2.Text.Split(","))
            {
                sampletwo.Add(double.Parse(s));
            }
            double meanone = sampleone.Average();
            double meantwo = sampletwo.Average();
            var squaredone = sampleone.Sum(d => Math.Pow(d - meanone, 2));
            var squaredtwo = sampletwo.Sum(d => Math.Pow(d - meantwo, 2));
            double varianceone = (squaredone / (sampleone.Count() - 1));
            double variancetwo = (squaredtwo / (sampletwo.Count() - 1));
            double t = (meanone - meantwo) / Math.Sqrt((varianceone / sampleone.Count()) +
                (variancetwo / sampletwo.Count()));
            MessageBox.Show("" + t);
        }
    }
}
